#include "some.h"

int main()
{
    testPrint();
    testPrint(5);
    notATest();
    return 0;
}
