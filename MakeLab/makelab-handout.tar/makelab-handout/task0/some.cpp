#include "some.h"

void notATest()
{
    printf("Can I call this function?\n");
}

void testPrint()
{
    printf("Test successful!\n");
}

void testPrint(int a)
{
    for (int i = 0; i < a; ++i)
    {
        printf("Test successful! %d\n", i);
    }
    notATest();
}