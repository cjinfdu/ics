#include <cstdio>

void testPrint();

void testPrint(int num);