#include "shared.h"

void func0();