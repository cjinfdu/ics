#include "function1.h"

void func1(int t)
{
    doSomeCalc(t);
}