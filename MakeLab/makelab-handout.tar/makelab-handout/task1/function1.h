#include "shared.h"

void func1(int t);