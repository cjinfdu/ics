#include "function0.h"
#include "function1.h"

int main()
{
    func0();
    func1(10);
    return 0;
}