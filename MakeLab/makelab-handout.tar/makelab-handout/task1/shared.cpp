#include "shared.h"
#include <cstdio>
#include <cstring>

void printDebug()
{
    printf("Task1 debug mode enabled\n");
    printf("task1\n");
}

void print()
{
    printf("task1\n");
}

void doSomeCalc(int t)
{
    int a = 1, b = 1;
    for (int i = 0; i < t; ++i)
    {
        int c = a + b;
        a = b;
        b = c;

#ifdef DEBUG
        printf("%d\n", b);
#endif
    }
    printf("The %d-th item of the Fibonacci sequence is: %d\n", t, b);
}