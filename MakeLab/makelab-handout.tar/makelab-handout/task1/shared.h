// #ifndef SHARED
// #define SHARED
#include <string>

// std::string FOO = "hahaha";

void printDebug();

void print();

void doSomeCalc(int t);
// #endif