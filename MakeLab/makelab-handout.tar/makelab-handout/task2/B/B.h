#pragma once
#include <cstdio>
#include <string>

void B();
static std::string B_name = "Beta";