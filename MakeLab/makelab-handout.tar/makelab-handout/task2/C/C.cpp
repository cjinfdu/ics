#include "C.h"

void C()
{
    printf("C\n");
    printf("Name in A is %s\n", A_name.c_str());
}
