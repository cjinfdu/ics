#pragma once
#include <cstdio>
#include <string>
#include "../A/A.h"

void C();
