#include "A/A.h"
#include "B/B.h"
#include "C/C.h"

int main()
{
    A();
    B();
    C();
    return 0;
}