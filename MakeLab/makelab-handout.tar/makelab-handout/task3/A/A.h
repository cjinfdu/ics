#pragma once
#include <cstdio>
#include <string>
#include "../B/B.h"
 
void A();
static std::string A_name = "Alpha";