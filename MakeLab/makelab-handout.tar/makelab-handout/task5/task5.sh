# Write down your operations here

# You may want to change the password
Task5_Passwd=weak_password

echo $Task5_Passwd
echo $Task5_Passwd | $PWD/login