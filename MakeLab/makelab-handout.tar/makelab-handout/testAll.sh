echo task0
cd task0
make clean
make main
./main
make clean

echo 

echo task1
cd ../task1
make clean
make main0
./main0
make main1
./main1
make clean
make main1 debug=True
./main1
make clean

echo 

echo task2
cd ../task2
make clean
make main
size main
./main
make clean

echo 

echo task3
cd ../task3
make clean
make main
size main
./main
make clean

echo 

echo task4
cd ../task4
make clean
make main
./main
make clean

echo 

echo task5
cd ../task5
sh task5.sh